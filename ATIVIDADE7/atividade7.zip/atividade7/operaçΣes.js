var num1 = prompt("digite o primeiro número");
var num2 = prompt("digite o segundo número");

var soma = parseFloat(num1) + parseFloat(num2);
var sub = parseFloat(num1) - parseFloat(num2);
var multi = parseFloat(num1) * parseFloat(num2);
var div = parseFloat(num1) / parseFloat(num2);
var rest = parseFloat(num1) % parseFloat(num2);

alert(" a soma é: " + soma );
alert(" a subtração é: " + sub );
alert(" a multiplicação é: " + multi );
alert(" a divisão é: " + div );
alert(" o resto é: " + rest );