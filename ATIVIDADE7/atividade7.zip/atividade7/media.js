

var nome = prompt("Qual é o seu nome?");
var nota1 = prompt("digite a primeira nota");
var nota2 = prompt("digite a segunda nota");
var nota3 = prompt("digite a terceira nota");

var media = (parseFloat(nota1) + parseFloat(nota2) + parseFloat(nota3)) / 3;

alert(" a média do aluno" + nome + " é " + media.toFixed(2));
