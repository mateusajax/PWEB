var sql = require ('mssql/msnodesqlv8'); 
module.exports = function(){ 
 
 const config = { 
 user: 'BD2213020', 
 password: 'A12345678a', 
 database: 'BD', //Na FATEC, utilizar o database BD ou LP8 
 server: 'Apolo', //Na FATEC, utilizar o ip: 192.168.1.6 no nome do servidor 
 driver: 'msnodesqlv8', 
 } 
 return sql.connect(config); 
} 
